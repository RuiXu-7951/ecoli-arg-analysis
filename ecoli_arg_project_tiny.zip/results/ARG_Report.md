
# Clinical E. coli Harbor 40x More Antibiotic Resistance Genes Than Environmental Strains

**Author**: [Your Name]  
**Date**: October 29, 2025  

## Abstract
We compared antibiotic resistance in two *E. coli* genomes: one clinical (SRR9694420), one environmental (SRR390728). The clinical strain had **40 unique ARGs**; the environmental had **0**.

## Methods
- Assembly: SPAdes  
- ARG detection: ABRicate (CARD)  
- Analysis: Python (pandas, seaborn)

## Results
![Plot](results/ARG_Comparison.png)

**Conclusion**: Hospitals select for multidrug resistance.

---

*Download this notebook and figure for full reproducibility.*
